package com.finalproject.truck.model;

public class CarRoute {
	//not use
}
