import { FilterstatusPipe } from './filterstatus.pipe';

describe('FilterstatusPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterstatusPipe();
    expect(pipe).toBeTruthy();
  });
});
