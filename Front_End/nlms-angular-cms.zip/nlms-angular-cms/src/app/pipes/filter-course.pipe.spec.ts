import { FilterCoursePipe } from './filter-course.pipe';

describe('FilterCoursePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCoursePipe();
    expect(pipe).toBeTruthy();
  });
});
