export class Route {
	constructor(public id: number,
		public startPoint: string,
		public endPoint: string,
		public startDate: string,
		// created_by,slider.created_date,slider.last_modified_by,slider.last_modified_date
	)
	{};
} 