export class User {
	constructor(
		public id: number,
		public fullName: string,
		public username: string,
		public email :string,
		public password : string,
		public avatar_Url :string,
		public phone:string
		)
	{};
}
