import { Setting } from './setting';

export class Document {
    public id: number;
	public type: Setting;
	public url: string;

}

