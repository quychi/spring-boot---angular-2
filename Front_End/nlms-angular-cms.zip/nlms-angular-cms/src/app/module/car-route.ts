export class CarRoute {
    constructor(
        public idCar: number,
		public idRoute: number,
	)
	{};
}
