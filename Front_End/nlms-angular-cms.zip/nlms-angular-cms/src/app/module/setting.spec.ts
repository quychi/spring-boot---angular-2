import { Setting } from './setting';

describe('Setting', () => {
  it('should create an instance', () => {
    expect(new Setting()).toBeTruthy();
  });
});
