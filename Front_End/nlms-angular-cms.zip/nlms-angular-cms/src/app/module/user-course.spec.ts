import { UserCourse } from './user-course';

describe('UserCourse', () => {
  it('should create an instance', () => {
    expect(new UserCourse()).toBeTruthy();
  });
});
