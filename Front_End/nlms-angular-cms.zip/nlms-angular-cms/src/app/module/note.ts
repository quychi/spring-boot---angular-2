export class Note {
    constructor(
        public id: number,
        public note: string,
        // public createdByUser: string,        // slider.created_date,slider.last_modified_by,slider.last_modified_date
    )
    {};
}
