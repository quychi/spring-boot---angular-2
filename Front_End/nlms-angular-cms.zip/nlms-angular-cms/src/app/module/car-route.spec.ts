import { CarRoute } from './car-route';

describe('CarRoute', () => {
  it('should create an instance', () => {
    expect(new CarRoute()).toBeTruthy();
  });
});
