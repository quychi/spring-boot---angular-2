import { Lessons } from './lessons';

describe('Lessons', () => {
  it('should create an instance', () => {
    expect(new Lessons()).toBeTruthy();
  });
});
