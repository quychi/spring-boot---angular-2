export class Note {
    constructor(
		public id: number,
		public message: string
		)
	{};
}
