import { Lesson } from './lesson';

describe('Lesson', () => {
  it('should create an instance', () => {
    expect(new Lesson()).toBeTruthy();
  });
});
