import { Route } from './route';

describe('Route', () => {
  it('should create an instance', () => {
    expect(new Route()).toBeTruthy();
  });
});
