export class Contact {
	public id: number;
	public name: string;	
	public email: string;
	public message: string;
	public status: string;
}
