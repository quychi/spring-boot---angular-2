export class Permission {
	public id: number;
	public name: string;
	public description: string;
	public action: string;
}
