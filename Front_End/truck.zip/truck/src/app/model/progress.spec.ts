import { Progress } from './progress';

describe('Progress', () => {
  it('should create an instance', () => {
    expect(new Progress()).toBeTruthy();
  });
});
