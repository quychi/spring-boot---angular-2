export class Setting {
	public id: number;
	public groupType: string;
	public value: string;
	public name: string;
	public description: string;
}
