export class Slider {
	public id: number;
	public title: string;
	public imgUrl: string;
	public text: string;
	public status: string;
}
