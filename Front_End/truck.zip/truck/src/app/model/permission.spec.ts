import { Permission } from './permission';

describe('Permission', () => {
  it('should create an instance', () => {
    expect(new Permission()).toBeTruthy();
  });
});
