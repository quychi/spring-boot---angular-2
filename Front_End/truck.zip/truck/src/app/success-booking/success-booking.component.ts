import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-booking',
  templateUrl: './success-booking.component.html',
  styleUrls: ['./success-booking.component.css']
})
export class SuccessBookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  deleteBooking(){
    
  }

}
